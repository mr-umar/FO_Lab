/*
** Fichero: sesion7_ej3a.c
** Autor: Umar Mohammad Riaz
** Fecha: 27/12/2024
**
** Descripción: Ejercicio 3a de la sesión 7 de laboratorio.
*/

#ifndef SESION7_EJ3A_H
#define SESION7_EJ3A_H

int menu();
double potencia(double base, unsigned int exponente);
unsigned long factorial(unsigned int n);
unsigned long combinatorio(unsigned int m, unsigned int n);

#endif
